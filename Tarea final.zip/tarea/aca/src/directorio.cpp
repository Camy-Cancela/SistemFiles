/* 4927427 */ // sustituiir con los 7 dígitos de la cédula

#include "../include/directorio.h"
#include "../include/archivo.h"
#include "../include/linea.h"
#include "../include/fila.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

typedef char* Cadena;
typedef struct listaArchivo* TlistaArchivos;
struct listaArchivo{
    TArchivo archivo;
    listaArchivo* siguiente;
};

struct _rep_directorio {
    Cadena nombre;
    Cadena ruta;
    int cantidadArchivos;  
    TDirectorio sh;
    TDirectorio ph;
    TDirectorio raiz;
    TDirectorio father;
    TlistaArchivos primerNodo;
};


//Crea el directorio de nombre Raíz del filesystem 
TDirectorio createRootDirectory() {
    TDirectorio raiz = new _rep_directorio;
    raiz->primerNodo = NULL;
    raiz->nombre = new char;
    raiz->ruta = new char;
    strcpy(raiz->nombre, "RAIZ\0");
    strcpy(raiz->ruta, "RAIZ\0");  
    raiz->cantidadArchivos = 0;
    raiz->raiz = raiz;
    raiz->sh = NULL;
    raiz->ph = NULL;
    raiz->father = NULL;
    return raiz;
}

// Retorna true si el directorio "directorio" no tiene archivos
bool isEmptyDirectory(TDirectorio directorio) {
    return (directorio->primerNodo == NULL);
}

// Retorna true si el archivo de nombre "nombreArchivo" existe en el directorio "directorio"
bool existFileDirectory(TDirectorio directorio, Cadena nombreArchivo) {
    bool encontro = false;
    if(!isEmptyDirectory (directorio)){
        TlistaArchivos aux = directorio->primerNodo;  
        while(!encontro && aux != NULL){
            Cadena nombre = getFileName(aux->archivo);
            if(strcmp(nombre, nombreArchivo) == 0){
                encontro = true;
            }
            aux = aux->siguiente;
        }
    }
    return encontro;    
}

//pre-condicion existe el archivo de nombre nombreArchivo en el directorio "directorio"
//pos-condicion: retorna un puntero al archivo de nombre "nombreArchivo"
TArchivo getFileDirectory(TDirectorio directorio, Cadena nombreArchivo) {
    TlistaArchivos aux = directorio->primerNodo;
    while (aux != NULL) {
        if (strcmp(getFileName(aux->archivo), nombreArchivo) == 0) {
            return aux->archivo;  
        }
        aux = aux->siguiente;
    }
    return NULL;  
}

// Pre-condición: No existe en directorio un archivo de nombre "nombreArchivo"
// Crea un archivo vacío con nombre nombreArchivo y permiso de lectura/escritura
void createFileInDirectory(TDirectorio &directorio, Cadena nombreArchivo) { 
    TlistaArchivos archivoNuevo = new listaArchivo;
    char sep = '.';
    Cadena nombre = new char[strlen(nombreArchivo) + 1];
    strcpy(nombre, strtok(nombreArchivo, &sep));
    Cadena extension = new char[strlen(nombreArchivo) + 1];
    strcpy(extension, strtok(NULL, &sep));
    archivoNuevo->archivo = createEmptyFile(nombre, extension);
    archivoNuevo->siguiente = directorio->primerNodo;
    directorio->primerNodo = archivoNuevo;
    directorio->cantidadArchivos++;
    printf("HAY %d ARCHIVOS \n",directorio->cantidadArchivos );   
}

// Pre-condición: El archivo nombreArchivo existe en el directorio
// Pos-condición: Inserta una nueva fila al comienzo del archivo nombreArchivo conteniendo los caracteres de texto
void insertTextFile(TDirectorio &directorio, Cadena nombreArchivo, Cadena texto) {
    TArchivo archivo = getFileDirectory(directorio, nombreArchivo);
    insertChartsNewRow(archivo, texto);
    printf("Texto insertado en el archivo '%s' con éxito.\n", nombreArchivo);  
}

// Pre-condición: El archivo "nombreArchivo" existe en el directorio
// Pos-condición: Agrega al comienzo de la primera fila del archivo de nombre "nombreArchivo" los caracteres de "texto"
//                desplazando los caracteres existentes hacia la derecha
void insertCharsFileFirstLine(TDirectorio &directorio, Cadena nombreArchivo, Cadena texto) {
    TArchivo archivo = getFileDirectory(directorio, nombreArchivo);
    if (isEmptyRowFile(archivo)){
        insertChartsNewRow(archivo,texto);
    }else{
        insertChartsFirstRow(archivo,texto);
    }
    printf("Caracteres insertados al inicio de la primera fila del archivo '%s'.\n", nombreArchivo);
}

// Pre-condición: Existe el archivo de nombre "nombreArchivo" en el directorio "directorio"
// Pos-condición: Elimina el archivo del directorio "directorio" y libera toda la memoria utilizada por este
void deleteFileDirectory(TDirectorio &directorio, Cadena nombreArchivo) {
    TlistaArchivos aux = directorio->primerNodo;     
    TlistaArchivos aux2 = NULL;
    bool eliminar = false;
    while(!eliminar){
        Cadena nombre = getFileName(aux->archivo);
        if(strcmp(nombre, nombreArchivo) == 0){          
            eliminar = true;
        }else{
            aux2 = aux;
            aux = aux->siguiente;
        }
    }     
    if (aux2 == NULL){ 
        directorio->primerNodo = aux->siguiente;
        aux->siguiente = NULL;
        destroyFile(aux->archivo);
        delete aux;
    }
    else{
        aux2->siguiente = aux->siguiente;
        aux->siguiente = NULL;
        destroyFile(aux->archivo);
        delete aux;
    }    
    directorio->cantidadArchivos--;
    printf("Archivo '%s' eliminado con éxito.\n", nombreArchivo);
}

// Pre-condición: Existe el archivo de nombre "nombreArchivo" en el directorio "directorio"
// Post-condición: Elimina los "cantidad" caracteres iniciales del archivo "nombreArchivo"
void deleteCharsFile(TDirectorio &directorio, Cadena nombreArchivo, int cantidad) {
    TArchivo archivo = getFileDirectory(directorio, nombreArchivo);
    deleteCharterFile(archivo, cantidad);
}

// Pre-condición: Existe el archivo de nombre "nombreArchivo" en el directorio "directorio"
// Pos-condición: Le setea el permiso de escritura al archivo de nombre "nombreArchivo"
void setFilePermission(TDirectorio &directorio, Cadena nombreArchivo, bool permisoEscritura) {
    TArchivo archivo = getFileDirectory(directorio, nombreArchivo);
    setWritePermission(archivo, permisoEscritura);
    printf("Se ha cambiado el permiso de escritura para el archivo '%s'.\n", nombreArchivo); 
}

// Pre-condición: Existe el archivo de nombre "nombreArchivo" en el directorio "directorio"
// Post-condición: Imprime el contenido del archivo "nombreArchivo"
void printFile(TDirectorio &directorio, Cadena nombreArchivo) {
    TArchivo archivo = getFileDirectory(directorio, nombreArchivo);
    printf("Contenido del archivo '%s':\n", nombreArchivo);
    TFila filaActual = firstRowFile(archivo);
    int cont = 0;
    int lonTotal = getCountRow(archivo);
    while(!isEmptyRow(filaActual) && cont < lonTotal){
        printLineFile(archivo, cont);
        cont ++;
        filaActual = nextRow(filaActual);
    }     
    printf("\n");
    printf("Se imprimio el contenido del archivo\n");
}

// Pos-condición: Destruye toda la memoria asociada a directorio, incluyendo subdirectorios
void destroyDirectory(TDirectorio &directorio) {
    if(directorio != NULL){
        destroyDirectory(directorio->ph);
        destroyDirectory(directorio->sh);
        directorio->father = NULL;
        TlistaArchivos listaActual = directorio->primerNodo;
        TlistaArchivos aux = NULL;
        

        while(listaActual != NULL){
            aux = listaActual;
            listaActual = listaActual->siguiente;
            aux->siguiente = NULL;
            destroyFile(aux->archivo);
            delete aux;
        }
      
          
        directorio->primerNodo = NULL;
        delete[] directorio->nombre;
        delete[] directorio->ruta;
       
        directorio->raiz = NULL;
        directorio->ph = NULL;
        directorio->sh = NULL;
        delete directorio;
        directorio = NULL;

    }
}

// retorna directorio ruta del directorio
Cadena retornarRuta(TDirectorio directorio){
    return directorio->ruta;
}

//Retorna un puntero a un array con el nombre del directorio "directorio"
Cadena getNameDirectory(TDirectorio directorio){
    return directorio->nombre;
}

// Retorna true si el directory de nombre nombreDirectorioHijo es hijo del directorio "directorio"
bool existChildrenDirectory(TDirectorio directorio, Cadena nombreDirectorioHijo) {  
    TDirectorio child = directorio->ph;
    while (child != NULL) {
        Cadena nombre = child->nombre;
        if (strcmp(nombre,nombreDirectorioHijo ) == 0) {
            return true;
        }else{
            child = child->sh;
        }          
    }
    return false; 
}

// Pre-condición: el directorio de nombre nombreDirectorioHijo es hijo del directorio directorio
// Pos-condición: retorna un puntero al directorio de nombre nombreDirectorioHijo
TDirectorio moveChildrenDirectory(TDirectorio& directorio, Cadena nombreDirectorioHijo) {
    TDirectorio child = directorio->ph;
    while (child != NULL) {
        Cadena nombre = child->nombre;
        if (strcmp(nombre, nombreDirectorioHijo) == 0) {
            return child;
        }else{
            child = child->sh;
        }       
    }
    return child;
}

//retorna un puntero de TDirectorio al padre del directorio directorio
TDirectorio moveFatherDirectory(TDirectorio& directorio) {
    return directorio->father;   
}

// Retorna un puntero de TDirectorio al directorio ROOT
TDirectorio moveRootDirectory(TDirectorio& directorio) {
    return directorio->raiz;  
}

// Retorna true si el directorio es el directorio raíz (sin director padre)
bool isRootDirectory(TDirectorio directorio) {
    return (directorio->father == NULL);
}

//Pre-Condición del directorio de nombre nombreDirectorio no es hijo del directorio "directorio"
//pos-condición crea un directorio vacío, de nombre nombreDirectorio, hijo del directorio "directorio"
void createChildrenDirectory(TDirectorio& directorio, Cadena nombreDirectorio) {
    TDirectorio nuevoDirectorio = new _rep_directorio;
    nuevoDirectorio->nombre = new char[strlen(nombreDirectorio) + 1];
    strcpy(nuevoDirectorio->nombre, nombreDirectorio);
    nuevoDirectorio->primerNodo = NULL;
    nuevoDirectorio->cantidadArchivos = 0;
    nuevoDirectorio->ph = NULL;
    nuevoDirectorio->sh = NULL;
    nuevoDirectorio->father = directorio;
    
    if(directorio->raiz == NULL){
        nuevoDirectorio->raiz = directorio;
    }else{
        nuevoDirectorio->raiz = directorio->raiz;
    }
    
    nuevoDirectorio->ruta = new char;
    strcpy(nuevoDirectorio->ruta, directorio->ruta);
    strcat(strcat(nuevoDirectorio->ruta, "/\0"), nombreDirectorio);

    if (directorio->ph == NULL || strcmp(nuevoDirectorio->nombre, directorio->ph->nombre) < 0) {
        nuevoDirectorio->sh = directorio->ph;
        directorio->ph = nuevoDirectorio;
    } else {
        TDirectorio ultimoHijo = directorio->ph;
        while (ultimoHijo->sh != NULL && strcmp(nuevoDirectorio->nombre, directorio->ph->nombre) > 0) {
            ultimoHijo = ultimoHijo->sh;
        }
        nuevoDirectorio->sh = ultimoHijo->sh;
        ultimoHijo->sh = nuevoDirectorio;
    }
    printf("Directorio '%s' creado como hijo de '%s'.\n", nombreDirectorio, directorio->nombre);
}

// Pre-condición: el directorio de nombre nombreDirectorioHijo es hijo del directorio directorio
// Pos-condición: elimina el directorio de nombre nombreDirectorioHijo que es hijo del directorio directorio
// eliminando toda su memoria
void removeChildrenDirectory(TDirectorio& directorio, Cadena nombreDirectorio) {
    TDirectorio child = directorio->ph;
    TDirectorio aux1 = NULL;

    while (child != NULL && strcmp(child->nombre, nombreDirectorio) != 0) {
        aux1 = child;
        child = child->sh;
    }

    if (child == NULL) {
        return;
    }

    if (aux1 == NULL) {
        directorio->ph = child->sh;
    } else {
        aux1->sh = child->sh;
    }

    destroyDirectory(child);

    while (child != NULL) {
        TDirectorio siguiente = child->sh;
        destroyDirectory(child);
        child = siguiente;
    }
}

// Busca un directorio por su ruta en el sistema de archivos
TDirectorio findDirectoryByPath(TDirectorio directorio, Cadena destino) {
    if (directorio == NULL) {
        return NULL;
    }else{
        Cadena camino = directorio->ruta;
        if (camino != NULL && strcmp(camino, destino) == 0) {
            return directorio;
        }

        TDirectorio encontre = findDirectoryByPath(directorio->ph, destino);
        if (encontre != NULL) {
            return encontre;
        }
        TDirectorio encontre2 = findDirectoryByPath(directorio->sh, destino);
        if (encontre2 != NULL) {
            return encontre2;
        }
    }
    return NULL;
}

//pre-condición el directorio origen es sub-directorio del directorio "directorio"
//pos-condición mueve el directorio origen y todo su contenido al directorio destino
void moveSubDirectory(TDirectorio& directorio, TDirectorio origen, TDirectorio& destino) {
    if (directorio == NULL || origen == NULL || destino == NULL) {
        printf("Error: Uno de los directorios es nulo.\n");
        return;
    }
    
    if (directorio->ph == origen) {
        directorio->ph = origen->sh;
    } else {
        TDirectorio child = directorio->ph;
        while (child != NULL && child->sh != origen) {
            child = child->sh;
        }
        if (child != NULL) {
            child->sh = origen->sh;
        }
    }

    Cadena name = origen->nombre;
    if (existChildrenDirectory(destino, name)) {
        removeChildrenDirectory(destino, name);
    }

    if (destino->ph == NULL || strcmp(destino->ph->nombre, name) > 0) {
        origen->sh = destino->ph;
        destino->ph = origen;
    } else {
        TDirectorio child = destino->ph;
        while (child->sh != NULL && strcmp(name, child->sh->nombre) > 0) {
            child = child->sh;
        }
        origen->sh = child->sh;
        child->sh = origen;
    }

    delete[] origen->ruta;
    origen->ruta = new char;
    strcpy(origen->ruta, destino->ruta);
    strcat(strcat(origen->ruta, "/\0"), name);

    printf("Directorio '%s' y su contenido movido a '%s'.\n", name, retornarRuta(destino));
}

//pre-condición el archivo origen es sub archivo del directorio directorio
//pos-condición se mueve el archivo TArchivo como hijo del directorio destino
void moveSubArchive(TDirectorio& directorio, TArchivo origen, TDirectorio destino) {
    if (directorio == NULL || origen == NULL || destino == NULL) {
        printf("Error: Uno de los directorios es nulo.\n");
        return;
    }
    TlistaArchivos punteroActual = directorio->primerNodo;
    TlistaArchivos punteroAnterior = NULL;

    while (punteroActual != NULL && punteroActual->archivo != origen) {
        punteroAnterior = punteroActual;
        punteroActual = punteroActual->siguiente;
    }

    if (punteroActual != NULL) {
        if (punteroAnterior != NULL) {
            punteroAnterior->siguiente = punteroActual->siguiente;
        } else {
            directorio->primerNodo = punteroActual->siguiente;
        }

        delete punteroActual;

        if (!existFileDirectory(destino, getFileName(origen))) {
            TlistaArchivos nuevoNodo = new listaArchivo;
            nuevoNodo->archivo = origen;
            nuevoNodo->siguiente = NULL;

            nuevoNodo->siguiente = destino->primerNodo;
            destino->primerNodo = nuevoNodo;
        }
    }
    printf("Archivo '%s' movido de '%s' a '%s'.\n", getFileName(origen), retornarRuta(directorio), retornarRuta(destino));
}

//pre-condición: directorio no es el directorio ROOT
//pos-condición: retorna un puntero al primer hermano del diretorio "directorio"
TDirectorio firstBrotherDirectory(TDirectorio directorio) {
    return directorio->sh;
}

//pos-condición: retorna un puntero al primer hijo del directorio "directorio"
TDirectorio firstChildrenDirectory(TDirectorio directorio) {
        return directorio->ph;  
}


// Retorna true si el directorio "subdir" es un subdirectorio del directorio "directorio" en cualquier nivel.
bool isSubDirectoryRoot(TDirectorio directorio, Cadena subdir) {
    if (directorio == NULL) {
        return false;
    }else{
        TDirectorio hijo = directorio->ph;
        while(hijo != NULL){
            if(strcmp(hijo->nombre, subdir) == 0 ){
      
                return true;
            }else{
                hijo = hijo->sh;
            }
         }
        return false;
    }  
}
//pos-condición imprime el directorio ejecutando DIR
void printDirectoryDir(TDirectorio directorio) {
    if (directorio != NULL) {
        printf("Contenido de %s:\n", directorio->ruta);

        TlistaArchivos archivoActual = directorio->primerNodo;

        if (archivoActual == NULL && directorio->ph == NULL) {
            printf("El directorio está vacío.\n");
        } else {
            while (archivoActual != NULL) {
                if (haveWritePermission(archivoActual->archivo)) {
                    printf("Archivo: %s (Lectura/Escritura)\n", getFileName(archivoActual->archivo));
                } else {
                    printf("Archivo: %s (Lectura)\n", getFileName(archivoActual->archivo));
                }
                archivoActual = archivoActual->siguiente;
            }

            TDirectorio subDirectorio = directorio->ph;
            while (subDirectorio != NULL) {
                printf("Directorio: %s\n", subDirectorio->nombre);
                subDirectorio = subDirectorio->sh;
            }
        }
    } else {
        printf("Error: El directorio es nulo.\n");
    }
}

//pos-condición imprime el directorio ejecutando DIR /S
void printDirectoryDirS(TDirectorio directorio) {
    if (directorio != NULL) {     
        printf("%s\n", directorio->ruta);
        
        TlistaArchivos archivoActual = directorio->primerNodo;
        if (archivoActual == NULL && directorio->ph == NULL) {
            printf("El directorio está vacío.\n");
        } else {
            while (archivoActual != NULL) {
                printf("%s/", directorio->ruta);
                printf("%s\n", getFileName(archivoActual->archivo));
                archivoActual = archivoActual->siguiente;
            }
            printDirectoryDirS(directorio->ph);    
            printDirectoryDirS(directorio->sh);
        }
    }
}
