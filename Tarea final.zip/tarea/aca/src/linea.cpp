/* 4927427 */ // sustituiir con los 7 dígitos de la cédula
/*
 Modulo que implemente el archivo linea.h
 
 */

#include "../include/linea.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct _rep_linea {
    char contenido;
    TLinea siguiente;
};

//Pos-condicion: Crea una linea vacía
TLinea createLine (){
    return NULL;
}

//pos-condicion: Retorna true si la linea "linea" es vacia
bool isEmptyLine(TLinea linea) {
    return (linea == NULL);
}

//pre-condicion: linea != NULL
//Inserta el caracter letra al inicio de la linea.
void insertCharLine(char letra, TLinea& linea){
    if(linea == NULL){
        TLinea nuevaLinea = new struct _rep_linea;
        nuevaLinea->contenido = letra;
        nuevaLinea->siguiente = NULL;
        linea = nuevaLinea;
    }
    else{
        TLinea nuevaLinea = new struct _rep_linea;
        nuevaLinea->contenido = letra;
        nuevaLinea->siguiente = linea;
        linea = nuevaLinea;
    }
}

//pre-condición linea != NULL
//Retorna el primer caracter de la linea "linea"
char firstCharLine(TLinea linea){
    return linea->contenido;
}

//pre-condicion linea !=NULL
//Retorna un puntero a al siguiente nodo de "linea"
TLinea nextLine(TLinea linea){
    return linea->siguiente;
}

//Retorna la cantidad de elementos que tiene la linea "linea"
int countNodesLine(TLinea linea){
    int count = 0; 
    while (linea != NULL) {
        count++; 
        linea = linea->siguiente; 
    }
    return count;
}

//pre-condicion: linea != NULL
//pos-condicion: Elimina el primer nodo de la linea "linea"
void deleteFirstChar(TLinea& linea){
    TLinea nodoAEliminar = linea; 
    TLinea aux = linea->siguiente;
    linea = aux; 
    nodoAEliminar->siguiente = NULL;
    delete(nodoAEliminar); 
}

//pre-condicion: linea != NULL
//pos-condicion: Elimina el ultimo nodo de la linea "linea"
void deleteLastChar(TLinea& linea){
    if (linea->siguiente == NULL) {
        delete (linea);
        linea = NULL; 
    } else {
        TLinea nodoAnterior = NULL;
        TLinea nodoActual = linea;
        while (nodoActual->siguiente != NULL) {
            nodoAnterior = nodoActual;
            nodoActual = nodoActual->siguiente;
        }
        delete(nodoActual);
        nodoAnterior->siguiente = NULL;
    }
}

//Pos-condicion: Destruye toda la memoria utilizada por linea
void destroyLine(TLinea& linea) {
    while (linea != NULL) {
        TLinea nodoAEliminar = linea;
        linea = linea->siguiente;
        delete(nodoAEliminar);
    }
}    