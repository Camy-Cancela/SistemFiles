/* 4927427 */ // sustituiir con los 7 dígitos de la cédula

#include "../include/archivo.h"
#include "../include/linea.h"
#include "../include/fila.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

 struct _rep_archivo {
    Cadena nombre;
    Cadena extension;
    bool permisoEscritura;
    int cantidadFilas;
    TFila filas;
} ;

typedef char* Cadena;
typedef _rep_archivo* TArchivo;

TArchivo createEmptyFile(Cadena nombreArchivo, Cadena extension) {
    TArchivo nuevoArchivo = new _rep_archivo;
    nuevoArchivo->nombre = new char[15];
    nuevoArchivo->extension = new char[3];
    strcpy(nuevoArchivo->nombre, nombreArchivo);
    strcpy(nuevoArchivo->extension, extension);
    nuevoArchivo->permisoEscritura = new bool;
    nuevoArchivo->cantidadFilas = 0;
    nuevoArchivo->filas = NULL;
    
    return nuevoArchivo;
}

//Retorna un puntero a un array con el nombre del archivo "archivo"
char* getFileName(TArchivo archivo) {
    size_t nombre = strlen(archivo->nombre);
    size_t extension = strlen(archivo->extension);
    Cadena nombreArchivo =  new char [nombre + 1 + extension];
    strcpy(nombreArchivo, archivo->nombre);
    nombreArchivo[nombre] = '.';
    strcpy(nombreArchivo + nombre  + 1, archivo->extension);
    return  nombreArchivo;
}

//Retorna true si archivo tiene permiso de escritura
bool haveWritePermission(TArchivo archivo) {
    return archivo->permisoEscritura == 1;
}

//retorna true si archivo no tiene filas;
bool isEmptyFile(TArchivo archivo) {
    return (archivo->filas == NULL);
}

//Retorna un puntero a la primer Fila de archivo
TLinea getFirstRow(TArchivo archivo) {
    if (archivo != NULL) {
        return headRow(archivo->filas);
    } else {
        return NULL; 
    }
}

//Retorna un puntero a la siguiente Fila de archivo
TLinea getNextRow(TArchivo archivo) {
    if (archivo != NULL && archivo->filas != NULL) {
       TFila sigFila = nextRow(archivo->filas);
       return headRow(sigFila);
    }
    else{
        return NULL;  

    }
}

//Retorna la cantidad de Fila que tiene el archvio "archivo"
int getCountRow(TArchivo archivo) {
    return archivo->cantidadFilas;
}

//Retorna la cantidad de caracteres que tiene el archvio "archivo"
int getCountChars(TArchivo archivo) {
    int totalCaracteres = 0;
    TFila filaActual = archivo->filas;
    while(filaActual != NULL){
        TLinea lineaActual = headRow(filaActual);
        totalCaracteres += countNodesLine(lineaActual);       
        filaActual = nextRow(filaActual);
    }
    return totalCaracteres;
}

//Retorna retorna un puntero a la primer fila del archivo "archivo"
TFila firstRowFile(TArchivo archivo) {
    if (archivo != NULL) {
        return archivo->filas; 
    } else {
        printf("Error: archivo es NULL. No se puede obtener la primera fila.\n");
        return NULL;
    }
}

//Retorna retorna un puntero a la siguiente fila del "archivo"
TFila nextRowFile(TArchivo archivo) {
    if (archivo != NULL && archivo->filas != NULL) {
        return nextRow(archivo->filas);
    }
    else{
         printf("Error: Archivo nulo. No se puede obtener la siguiente fila.\n");
        return NULL;
    }
}


//retorna true si archivo no tiene filas, es decir el archivo es vacio.
bool isEmptyRowFile(TArchivo archivo) {
    if(archivo != NULL){
        return isEmptyRow(archivo->filas);
    }
    else {
        printf("Error: Archivo nulo.\n");
        return true;
    }
}

//imprime la Linea del archivo indicada por "numero_linea"
//pre-condición el archivo tiene por lo menos numero_linea de lineas
void printLineFile(TArchivo archivo, int numero_linea) {
    int cont = 0;
    bool encontro = false;
    TFila filaActual = archivo->filas;
    while(!encontro && filaActual != NULL){
        if (numero_linea == cont){
            TLinea lineaActual = headRow(filaActual);
            while(lineaActual != NULL){
                printf("%c", firstCharLine(lineaActual));
                lineaActual = nextLine(lineaActual);
            }
            encontro = true;
        }
        filaActual = nextRow(filaActual);
        cont++;   
    }
    printf("\n");
}
    
//Elimina los cant cantidad de caracteres finales del "archivo"
//En caso que el archivo tenga menos caracteres los elimina a todos
void deleteCharterFile(TArchivo &archivo, int cant) {
    TFila primerFila = archivo->filas;
    TFila filaActual = archivo->filas;
    TFila aux = archivo->filas;
    while(nextRow(filaActual) !=NULL){
        filaActual = nextRow(filaActual);
    }
    int borrados = 0;
    TLinea lineaBorrar = headRow(filaActual);
    while(borrados <= cant && headRow(filaActual) != NULL){
        while(nextRow(aux) != filaActual && nextRow(aux) != NULL){
            aux = nextRow(aux);
        }
        while(borrados <= cant && lineaBorrar != NULL){
            deleteLastChar(lineaBorrar);
            borrados ++;
        }
        filaActual = aux;
        aux = primerFila;
        lineaBorrar = headRow(filaActual);
    }
}

//Cambia el nombre del archivo "archivo" por nuevoNombre
void setName(TArchivo &archivo, Cadena nuevoNombre) {
    if (archivo != NULL && nuevoNombre != NULL) {
        delete(archivo->nombre);
        archivo->nombre = new char[15];
        strcpy(archivo->nombre, nuevoNombre);
    }
}
//Cambia la extension del "archivo" por nuevoNombre
void setExtension(TArchivo &archivo, Cadena nuevaExtension) {
    if (archivo != NULL && nuevaExtension != NULL) {
        delete(archivo->extension);
        archivo->extension = new char[3];
        archivo->extension = nuevaExtension;
    }
}

//Inserta el texto "texto" como una nueva fila al comienzo del archivo 
void insertChartsNewRow(TArchivo &archivo, Cadena texto) {
    if (archivo != NULL && texto != NULL){
        TLinea nuevaLinea = createLine();
        int longitud = strlen(texto);
        int cont = longitud - 1;
        while(cont > 0){
            insertCharLine(texto[cont], nuevaLinea);
            cont --;
        }  
        insertRow(archivo->filas, nuevaLinea);
        archivo->cantidadFilas++; 
    }
}
//pre-condicion El archivo tiene por lo menos una fila
//Inserta el texto "texto" al inicio de la primer fila del archivo
void insertChartsFirstRow(TArchivo &archivo, Cadena texto) {
    if (archivo != NULL && !isEmptyRow(archivo->filas)) {
        modifyRow(archivo->filas, texto);
    }
}

//si valor == true se le asigna el permiso de escritura de "archivo"
//si valor == false se le quita el permiso de escritura de "archivo"
//pre-condicion archivo !=NULL
void setWritePermission(TArchivo &archivo, bool valor) {
    archivo->permisoEscritura = valor;  
}

//elimina toda la memoria utilizada por "archivo"
void destroyFile(TArchivo &archivo) {
    if (archivo != NULL) {
        delete(archivo->nombre);
        delete(archivo->extension);
        deleteRows(archivo->filas);
        delete(archivo);
    }
}
