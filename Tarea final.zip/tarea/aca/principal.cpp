/*
Módulo principal de la tarea 1.FILE SYSTEM

Intérprete de comandos para probar los módulos.

  Laboratorio de EDA 2023
  UTU - LATU - Turno Nocturno 
  Profesor Ferando Arrieta
*/

#include "include/archivo.h"
#include "include/linea.h"
#include "include/fila.h"
#include "include/directorio.h"
#include "include/utils.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <cstddef>

#define MAX_PALABRA 64
#define MAX_LINEA 256
#define MAX_RUTA 256
#define MAX_PARAMETRO 10
#define MAX_PARAMETRODIR 1
#define MAX_COMANDO 10
#define MAX_NOMBRE 15
#define MAX_EXTENSION 3
#define TEXTO_MAX 50

enum _retorno {OK, NO_IMPLEMENTADA, ERROR};
typedef enum _retorno TipoRet;
typedef char* Cadena;

  
TipoRet CREARSISTEMA(TDirectorio &s);
TipoRet CREATE (TDirectorio &sistema, char *nombreArchivo);
TipoRet DELETE (TDirectorio &sistema, char *nombreArchivo);
TipoRet ATTRIB (TDirectorio &sistema, char *nombreArchivo, char* parametro);
TipoRet IF (TDirectorio &sistema, char *nombreArchivo, char* texto);
TipoRet IN (TDirectorio &sistema, char *nombreArchivo, char* texto);
TipoRet DF (TDirectorio &sistema, char *nombreArchivo, char* cantidad);
TipoRet TYPE (TDirectorio &sistema, char *nombreArchivo);
TipoRet DESTRUIRSISTEMA (TDirectorio &sistema);
TipoRet CD (TDirectorio &sistema, char *nombreDirectorio);
TipoRet MKDIR (TDirectorio &sistema, char *nombreDirectorio);
TipoRet RMDIR (TDirectorio &sistema, char *nombreDirectorio);
TipoRet MOVE (TDirectorio &sistema, char *nombre, char *directorioDestino);
TipoRet DIR (TDirectorio &sistema, char *parametro);


// programa principal
int main() {
    char restoLinea[MAX_LINEA + 1];
    char comando[MAX_PALABRA];
    char parametro[MAX_PALABRA];
    char texto[MAX_PALABRA];
    char nombrearchivo[MAX_NOMBRE];
    char cantidad [MAX_PALABRA];
    char nombre[MAX_NOMBRE];
    char nombreDirectorio[MAX_NOMBRE];
    char directorioDestino[MAX_RUTA];
    //char parametro;
    TDirectorio sistema;
    TDirectorio root;
    int sistemaInicializado=false;
    bool salir = false;
    while (!salir) {
        printf("#");	
        // leer el comando
        leerChars(comando);
        if (!strcmp(comando,"ATTRIB")){
            leerChars(nombrearchivo);
            leerChars(parametro);
            printf("El comando es:%s\n",comando); 
            printf("El nombre de archivo es:%s\n",nombrearchivo);
            printf("El parametro es:%s\n",parametro);
        }
        else if (!strcmp(comando,"CREATEFILE"))
                leerChars(nombrearchivo);
        
        else if (!strcmp(comando,"DELETE"))
                leerChars(nombrearchivo);
        
        else if (!strcmp(comando,"IF")){
                leerChars(nombrearchivo);
                leerRestoLinea(texto);
        }
        else if (!strcmp(comando,"IN")){
                leerChars(nombrearchivo);
                leerRestoLinea (texto);
                printf("El comando es:%s\n",comando); 
                printf("El nombre de archivo es:%s\n",nombrearchivo);
                printf("El texto es:%s\n",texto);
        }
        else if (!strcmp(comando,"DF")){
                leerChars(nombrearchivo);
                leerChars(cantidad);
        }        
        else if (!strcmp(comando,"TYPE")){
                leerChars(nombrearchivo);
        }
        else if(!strcmp(comando,"CD")){
                leerChars(nombreDirectorio);
        }
        else if(!strcmp(comando,"MKDIR")){
                leerChars(nombreDirectorio);
        }
        else if(!strcmp(comando,"RMDIR")){
                leerChars(nombreDirectorio);
        }
        else if(!strcmp(comando,"MOVE")){
                leerChars(nombre);
                leerRestoLinea(directorioDestino);
        }
        else if(!strcmp(comando,"DIR")){
                leerRestoLinea(parametro);
        }
                
        
        // *********************** Procesamiento de comandos ***********************************
        
        
        if (0 == strcmp(comando, "CREARSISTEMA")) {
            if (!sistemaInicializado){
                TipoRet salida=CREARSISTEMA(sistema);
                if (salida == OK){
                    sistemaInicializado=true;
                    root = sistema;
                    printf("*** SYSTEM INICIALIZED ***\n");
                    printf("OK\n");
                }
            }   
            else 
                 printf("EL SISTEMA YA FUE INICIALIZADO\n");

        }else if (0 == strcmp(comando, "CREATEFILE")) {   
                TipoRet salida= CREATE(sistema, nombrearchivo);
                if (salida == OK)                  
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n"); 

        } else if (0 == strcmp(comando, "DELETE")) {
                TipoRet salida=DELETE(sistema,nombrearchivo);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");

        } else if (0 == strcmp(comando, "ATTRIB")) {
                TipoRet salida=ATTRIB(sistema, nombrearchivo,parametro);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
                
        } else if (0 == strcmp(comando, "IF")) {
                TipoRet salida=IF(sistema, nombrearchivo,texto);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
                
        } else if (0 == strcmp(comando, "IN")) {
                TipoRet salida=IN(sistema, nombrearchivo,texto);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
                
        } else if (0 == strcmp(comando, "DF")) {
                TipoRet salida=DF(sistema, nombrearchivo,cantidad);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
                
        } else if (0 == strcmp(comando, "TYPE")) {
                TipoRet salida=TYPE(sistema, nombrearchivo);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
                
        } else if (0 == strcmp(comando, "DESTRUIRSISTEMA")) {
                TipoRet salida=DESTRUIRSISTEMA(root);
                if (salida == OK){
                     sistemaInicializado = false; 
                     printf("OK\n");
                }      
                else if (salida == ERROR )
                                printf("ERROR\n");
        } else if (0 == strcmp(comando, "CD")) {
                TipoRet salida=CD(sistema, nombreDirectorio);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
        } else if (0 == strcmp(comando, "MKDIR")) {
                TipoRet salida=MKDIR(sistema, nombreDirectorio);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
        } else if (0 == strcmp(comando, "RMDIR")) {
                TipoRet salida=RMDIR(sistema, nombreDirectorio);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
        } else if (0 == strcmp(comando, "MOVE")) {
                TipoRet salida=MOVE(sistema, nombre, directorioDestino);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
        }else if (0 == strcmp(comando, "DIR")) {
                TipoRet salida=DIR(sistema, parametro);
                if (salida == OK)
                        printf("OK\n");
                else if (salida == ERROR )
                                printf("ERROR\n");
        }else {
            printf("Error: Comando incorrecto.\n");
        }
        fgets(restoLinea, MAX_LINEA + 1, stdin);
    } // while
    return 0;
} // main



//****************************** Funciones a implementar ************************************

TipoRet CREARSISTEMA(TDirectorio &sistema) {  
    sistema = createRootDirectory(); 
    return OK;    
}

TipoRet CREATE(TDirectorio &directorio, Cadena nombreArchivo) {
    if (!existFileDirectory(directorio, nombreArchivo)) { 
        createFileInDirectory(directorio, nombreArchivo);
        return OK;  
    } else {
        return ERROR;  
    }
 
}

TipoRet DELETE(TDirectorio &sistema, Cadena nombreArchivo) {  
    TipoRet res;
    TArchivo archivo = getFileDirectory(sistema, nombreArchivo); 
    if (existFileDirectory(sistema, nombreArchivo)) {
        if (haveWritePermission(archivo)) {
            deleteFileDirectory(sistema, nombreArchivo);
            res = OK;  
        }else {
            res = ERROR;  
        } 
    }   
    return res;
}

TipoRet ATTRIB(TDirectorio &sistema, Cadena nombreArchivo, Cadena parametros) {
    if (existFileDirectory(sistema, nombreArchivo)){
        bool permiso = false;
        if(strcmp(parametros, "+W") == 0){
            permiso = true;
        }else if(strcmp(parametros, "-W") == 0){
            permiso = false;
        }
        setFilePermission(sistema, nombreArchivo, permiso);
        return OK; 
    } else {
        return ERROR;  
    } 
    
}

TipoRet IF(TDirectorio &sistema, Cadena nombreArchivo, Cadena texto) {  
    TipoRet res;
    TArchivo archivo = getFileDirectory(sistema, nombreArchivo); 
    if (existFileDirectory(sistema, nombreArchivo)) {
        if (haveWritePermission(archivo)) {
            insertChartsNewRow(archivo, texto);
            int longitudAr = getCountChars(archivo);
            if(longitudAr > TEXTO_MAX){
                deleteCharsFile(sistema, nombreArchivo, longitudAr - TEXTO_MAX);
            }       
            res = OK; 
        }else{
            res = ERROR; 
        }
    }else{
       res = ERROR; 
    }
    return res; 
}

TipoRet IN(TDirectorio &sistema, Cadena nombreArchivo, Cadena texto) {
    TipoRet res;
    TArchivo archivo = getFileDirectory(sistema, nombreArchivo); 
    if (existFileDirectory(sistema, nombreArchivo)) {
         if (haveWritePermission(archivo)) {
            insertTextFile(sistema, nombreArchivo, texto);
            int longitudAr = getCountChars(archivo);
            if(longitudAr > TEXTO_MAX){
                deleteCharsFile(sistema, nombreArchivo, longitudAr - TEXTO_MAX);
            } 
            res = OK; 
        }else{
            res = ERROR; 
        }
    }else{
        res = ERROR; 
    }
    return res;
}

TipoRet DF(TDirectorio &sistema, Cadena nombreArchivo, Cadena cantidad) {
    TipoRet res;
    int cantidadAEliminar = atoi(cantidad);
    if (existFileDirectory(sistema, nombreArchivo)) {
        TArchivo archivo = getFileDirectory(sistema, nombreArchivo);
        if(haveWritePermission(archivo)){
            int cant = getCountChars(archivo);
            if(cantidadAEliminar > cant)
                cantidadAEliminar = cant;
            deleteCharsFile(sistema, nombreArchivo, cantidadAEliminar);
         res = OK;
        }    
    } else {
        printf("El archivo '%s' no existe en el directorio.\n", nombreArchivo);
        res = ERROR;
    }
    return  res;
}

TipoRet TYPE(TDirectorio &sistema, Cadena nombreArchivo) {
    if (existFileDirectory(sistema, nombreArchivo)) {
        printFile(sistema, nombreArchivo);
        return OK;  
    } else {
        return ERROR;  
    }
}

TipoRet DESTRUIRSISTEMA(TDirectorio &sistema) {
    destroyDirectory(sistema);
    return OK; 
}

TipoRet CD(TDirectorio& sistema, Cadena nombreDirectorio) {
    TipoRet res;
    if (strcmp(nombreDirectorio, "..") == 0) {
        if (!isRootDirectory(sistema)) {
            sistema = moveFatherDirectory(sistema);
            res = OK;
        } else {
            printf("Error: No se puede mover al directorio padre desde el directorio raíz.\n");
            res = ERROR;
        }
    } else if (strcmp(nombreDirectorio, "RAIZ") == 0) {
        sistema = moveRootDirectory(sistema);
        res = OK;
    } else if (existChildrenDirectory(sistema, nombreDirectorio)) {
        TDirectorio directorioHijo = moveChildrenDirectory(sistema, nombreDirectorio);
        sistema = directorioHijo;
        res = OK;
    } else {
        printf("Error: El directorio '%s' no existe en el directorio actual.\n", nombreDirectorio);
        res = ERROR;
    }

    return res;
}

TipoRet MKDIR(TDirectorio& sistema, Cadena nombreDirectorio) {
    if (strcmp(nombreDirectorio, "RAIZ") == 0) {
        return ERROR;
    }
    if (existChildrenDirectory(sistema, nombreDirectorio)) {
        printf("Error: El directorio '%s' ya existe en el directorio actual.\n", nombreDirectorio);
        return ERROR;
    } 
    createChildrenDirectory(sistema, nombreDirectorio);
    return  OK;
}

TipoRet RMDIR(TDirectorio &sistema, Cadena nombreDirectorio) {
    if(existChildrenDirectory(sistema,nombreDirectorio)){
        removeChildrenDirectory(sistema, nombreDirectorio);
        printf("Directorio '%s' eliminado con éxito.\n", nombreDirectorio);
        return OK;
    }
    return ERROR;
}

TipoRet MOVE(TDirectorio& sistema, Cadena nombre, Cadena directorioDestino) {
    TDirectorio destino = NULL;
    
    for (int i = 0; directorioDestino[i] != '\0'; ++i) {
        directorioDestino[i] = directorioDestino[i + 1];
    }
     if (sistema == NULL || nombre == NULL) {
        printf("Error: Sistema o nombre nulos.\n");
        return ERROR;
    }

    if (directorioDestino == NULL) {
        printf("Error: Directorio destino nulo.\n");
        return ERROR;
    }
    
    if (isRootDirectory(sistema)) {
        if (!isSubDirectoryRoot(sistema, nombre)) {
            printf("Primer error: el directorio origen no es subdirectorio de la raíz.\n");
            return ERROR;
        }
        destino = findDirectoryByPath(sistema, directorioDestino);
        if(destino == NULL) {
            printf("Error: El directorio destino '%s' no existe.\n", directorioDestino);
            return ERROR;
        }
    }else {
        TDirectorio root = moveRootDirectory(sistema);
        if (!isSubDirectoryRoot(sistema, nombre)) {
            printf("Segundo error: el directorio destino no es subdirectorio del subdirectorio raíz.\n");
            return ERROR;
        }   
        destino = findDirectoryByPath(root, directorioDestino);
        if(destino == NULL) {
            printf("Error: El directorio destino '%s' no existe.\n", directorioDestino);
            return ERROR;
        }
    }

    if (existChildrenDirectory(sistema, nombre)) {
        TDirectorio origen = moveChildrenDirectory(sistema, nombre);
        if (origen == destino) {
            printf("Error: No se puede mover a sí mismo.\n");
            return ERROR;
        }
        if (origen == NULL) {
            printf("Error: origen no existe.\n");
            return ERROR;
        }
        if (!isSubDirectoryRoot(origen, directorioDestino)) {
            moveSubDirectory(sistema, origen, destino);
            return OK; 
        }
    } else if (existFileDirectory(sistema, nombre)) {
        moveSubArchive(sistema, getFileDirectory(sistema, nombre), destino);//PORBLEMA CON DESTINO NULL
        printf("Archivo movido exitosamente.\n");
        return OK;
    }

    printf("Último error: no se pudo determinar la acción a realizar.\n");
    return ERROR;      
}

TipoRet DIR(TDirectorio &sistema, Cadena parametro) {
    if (strcmp(parametro, " /S") == 0) {
        printDirectoryDirS(sistema);
        strcpy(parametro, "");  
    } else {
         printDirectoryDir(sistema);
    }
    return OK;
}



